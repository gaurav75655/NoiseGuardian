package com.noiseguardian.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import kotlin.math.sqrt
import kotlin.concurrent.thread

class NoiseMonitorService : Service() {
    @Volatile private var running = false
    @Volatile private var alarmActive = false
    private var recorder: AudioRecord? = null
    private var monitorThread: Thread? = null
    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var threshold = 1800
    private var toneUri: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START && !running) {
            threshold = intent.getIntExtra(EXTRA_THRESHOLD, 1800)
            toneUri = intent.getStringExtra(EXTRA_TONE_URI)
            startForeground(NOTIFICATION_ID, buildNotification())
            startMonitoring()
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val channelId = "noise_guardian_monitor"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Noise monitoring", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Visible while Noise Guardian is listening for nearby sound"
                setShowBadge(false)
            })
        }
        val stopIntent = Intent(this, NoiseMonitorService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openIntent = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("Noise Guardian is listening")
            .setContentText("Microphone monitoring is active. Tap STOP to end.")
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stopPending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun startMonitoring() {
        val sampleRate = 44100
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) { stopSelf(); return }
        val bufferSize = maxOf(minBuffer, 4096)
        val audio = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        } catch (_: SecurityException) { stopSelf(); return }
        if (audio.state != AudioRecord.STATE_INITIALIZED) { audio.release(); stopSelf(); return }
        recorder = audio
        try {
            audio.startRecording()
            running = true
            wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NoiseGuardian:Monitor").apply { acquire() }
        } catch (_: Exception) { audio.release(); recorder = null; stopSelf(); return }

        monitorThread = thread(name = "NoiseGuardianAudio", isDaemon = true) {
            val samples = ShortArray(bufferSize / 2)
            var consecutiveLoud = 0
            while (running) {
                val count = try { audio.read(samples, 0, samples.size) } catch (_: Exception) { -1 }
                if (count > 0 && !alarmActive) {
                    var sum = 0.0
                    for (i in 0 until count) { val v = samples[i].toDouble(); sum += v * v }
                    val rms = sqrt(sum / count)
                    if (rms >= threshold) consecutiveLoud++ else consecutiveLoud = 0
                    if (consecutiveLoud >= 2) {
                        alarmActive = true
                        startAlarm()
                    }
                }
                if (count < 0) break
            }
        }
    }

    @Synchronized private fun startAlarm() {
        if (!running || player != null) return
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            val uri = toneUri?.let(Uri::parse)
            if (uri != null) mp.setDataSource(this, uri)
            else {
                val defaultAlarm = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                mp.setDataSource(this, defaultAlarm ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            }
            mp.isLooping = true
            mp.setOnPreparedListener { it.start() }
            mp.setOnErrorListener { _, _, _ -> true }
            mp.prepareAsync()
            player = mp
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, buildNotification().also {
                // Notification stays ongoing; alarm is audible until the user presses STOP.
            })
        } catch (_: Exception) {
            player?.release(); player = null
        }
    }

    private fun stopMonitoring() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        try { monitorThread?.join(300) } catch (_: InterruptedException) {}
        monitorThread = null
        synchronized(this) { try { player?.stop() } catch (_: Exception) {}; player?.release(); player = null }
        alarmActive = false
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            stopForeground(true)
        }
    }

    override fun onDestroy() { stopMonitoring(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.noiseguardian.action.START"
        const val ACTION_STOP = "com.noiseguardian.action.STOP"
        const val EXTRA_THRESHOLD = "threshold"
        const val EXTRA_TONE_URI = "tone_uri"
        private const val NOTIFICATION_ID = 41
    }
}
