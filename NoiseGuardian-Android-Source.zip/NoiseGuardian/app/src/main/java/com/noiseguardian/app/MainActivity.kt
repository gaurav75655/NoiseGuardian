package com.noiseguardian.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private var selectedTone: Uri? = null
    private var threshold = 1800
    private lateinit var thresholdLabel: TextView

    private val tonePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                selectedTone = uri
                getSharedPreferences("noise_guardian", MODE_PRIVATE).edit().putString("tone_uri", uri.toString()).apply()
                Toast.makeText(this, "Custom tone selected", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Could not access this audio file", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val micGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micGranted) startMonitoring() else Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedTone = getSharedPreferences("noise_guardian", MODE_PRIVATE).getString("tone_uri", null)?.let(Uri::parse)
        val prefs = getSharedPreferences("noise_guardian", MODE_PRIVATE)
        threshold = prefs.getInt("threshold", 1800)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFFF5F7F6.toInt())
        }
        fun addText(value: String, size: Float, color: Int = 0xFF17211D.toInt(), bold: Boolean = false): TextView {
            return TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
                root.addView(this, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }
        addText("NOISE GUARDIAN", 25f, 0xFF176B52.toInt(), true)
        addText("Nearby sound monitor", 15f, 0xFF65736C.toInt())
        addText("How it works", 18f, 0xFF17211D.toInt(), true)
        addText("When the microphone detects sound above your chosen sensitivity, the alarm starts and keeps looping until you press STOP. Audio is analyzed on this phone; recordings are not saved.", 15f)

        addText("Sensitivity", 18f, 0xFF17211D.toInt(), true)
        thresholdLabel = addText("Trigger threshold: $threshold (lower = more sensitive)", 14f, 0xFF52615A.toInt())
        val seek = SeekBar(this).apply {
            max = 9500
            progress = (threshold - 500).coerceIn(0, 9500)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    threshold = progress + 500
                    thresholdLabel.text = "Trigger threshold: $threshold (lower = more sensitive)"
                    getSharedPreferences("noise_guardian", MODE_PRIVATE).edit().putInt("threshold", threshold).apply()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        root.addView(seek, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val toneButton = Button(this).apply {
            text = "Choose custom alarm tone (MP3 / WAV)"
            setOnClickListener { tonePicker.launch(arrayOf("audio/*")) }
        }
        root.addView(toneButton)
        addText("If no custom tone is selected, the phone's default alarm sound is used.", 13f, 0xFF65736C.toInt())

        val start = Button(this).apply {
            text = "START LISTENING"
            setOnClickListener { requestPermissionsAndStart() }
        }
        root.addView(start)
        val stop = Button(this).apply {
            text = "STOP MONITORING / ALARM"
            setOnClickListener { stopService(Intent(this@MainActivity, NoiseMonitorService::class.java).setAction(NoiseMonitorService.ACTION_STOP)) }
        }
        root.addView(stop)
        addText("Privacy: microphone access is used only while monitoring is active. No internet permission, analytics, ads, or audio-file recording is included.", 13f, 0xFF52615A.toInt())
        addText("Keep the persistent monitoring notification visible. Android may stop microphone monitoring if the app is force-stopped or microphone access is revoked.", 12f, 0xFF7A5140.toInt())
        root.gravity = Gravity.TOP
        setContentView(root)
    }

    private fun requestPermissionsAndStart() {
        val required = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) required.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = required.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startMonitoring() else permissionRequest.launch(missing.toTypedArray())
    }

    private fun startMonitoring() {
        val intent = Intent(this, NoiseMonitorService::class.java).apply {
            action = NoiseMonitorService.ACTION_START
            putExtra(NoiseMonitorService.EXTRA_THRESHOLD, threshold)
            putExtra(NoiseMonitorService.EXTRA_TONE_URI, selectedTone?.toString())
        }
        try {
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, "Noise monitoring started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start monitoring: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
