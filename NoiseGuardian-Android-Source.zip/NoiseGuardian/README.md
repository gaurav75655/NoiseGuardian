# Noise Guardian (Android source project)

A minimal, local-only Android sound-threshold alarm prototype.

## Features
- Microphone level monitoring while the foreground service is active.
- A threshold slider (lower value = more sensitive).
- Starts a looping alarm after two consecutive audio buffers cross the threshold.
- Alarm continues until the user presses STOP in the app or ongoing notification.
- Optional custom audio URI selected with Android's system document picker; otherwise uses the device alarm tone.
- No INTERNET permission, analytics, ad SDK, or audio recording/storage code.

## Build an installable APK
1. Install Android Studio (current stable) on a computer.
2. Open this `NoiseGuardian` folder as an existing project.
3. Allow Gradle sync to download Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and Android SDK 35.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to the Android phone and install it. Android may ask you to allow installation from that file manager/browser.

## Important limitations
- This is a source prototype, not a compiled or device-tested APK.
- It detects sound by amplitude, not by understanding every sound type. Very quiet sounds may not cross the threshold; loud background noise can cause false triggers. Adjust sensitivity in the app.
- Android requires microphone permission and an ongoing foreground-service notification. Start monitoring while the app is visible. Force-stop, revoking microphone permission, or some vendor battery restrictions can stop monitoring.
- The app does not save or upload microphone audio. Android itself may show the system microphone indicator while monitoring.
- Custom tone playback depends on the chosen audio file being readable and supported by Android's MediaPlayer.
